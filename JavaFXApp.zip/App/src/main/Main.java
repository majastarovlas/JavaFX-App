package main;

import forms.LoginForma;
import static javafx.application.Application.launch;

public class Main {
    public static void main(String[] args) {
        launch(LoginForma.class, args);
    }
}
